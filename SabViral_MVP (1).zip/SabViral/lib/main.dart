import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const SabViralApp());

class SabViralApp extends StatelessWidget {
  const SabViralApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SabViral',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink, brightness: Brightness.dark),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final reels = <String>[
    'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
    'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: tab, children: [
        ReelsFeed(urls: reels),
        const Center(child: Text('Search', style: TextStyle(fontSize: 28))),
        const ProfilePage(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'Reels'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _upload(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<void> _upload(BuildContext context) async {
    final picker = ImagePicker();
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(file == null ? 'Upload cancelled' : 'Selected: ${file.name}. Backend upload is next.')),
    );
  }
}

class ReelsFeed extends StatefulWidget {
  final List<String> urls;
  const ReelsFeed({super.key, required this.urls});
  @override State<ReelsFeed> createState() => _ReelsFeedState();
}

class _ReelsFeedState extends State<ReelsFeed> {
  final page = PageController();
  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      controller: page,
      scrollDirection: Axis.vertical,
      itemCount: widget.urls.length,
      itemBuilder: (_, i) => Reel(url: widget.urls[i]),
    );
  }
}

class Reel extends StatefulWidget {
  final String url;
  const Reel({super.key, required this.url});
  @override State<Reel> createState() => _ReelState();
}

class _ReelState extends State<Reel> {
  late VideoPlayerController controller;
  bool liked = false;
  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) { if (mounted) setState(() {}); controller.setLooping(true); controller.play(); });
  }
  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(
        child: controller.value.isInitialized
          ? GestureDetector(
              onTap: () => controller.value.isPlaying ? controller.pause() : controller.play(),
              child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: controller.value.size.width, height: controller.value.size.height, child: VideoPlayer(controller))),
            )
          : const Center(child: CircularProgressIndicator()),
      ),
      Positioned(left: 16, bottom: 28, right: 90, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('@sabviral_creator', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        SizedBox(height: 8),
        Text('Welcome to SabViral! 🎬 #SabViral', style: TextStyle(fontSize: 15)),
      ])),
      Positioned(right: 12, bottom: 70, child: Column(children: [
        IconButton(icon: Icon(Icons.favorite, color: liked ? Colors.red : Colors.white, size: 34), onPressed: () => setState(() => liked = !liked)),
        const Text('Like'),
        IconButton(icon: const Icon(Icons.comment, size: 34), onPressed: () => _message('Comments coming next')),
        const Text('Comment'),
        IconButton(icon: const Icon(Icons.share, size: 34), onPressed: () => _message('Share coming next')),
        const Text('Share'),
      ])),
    ]);
  }
  void _message(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 50)),
    const SizedBox(height: 12),
    const Center(child: Text('@yourname', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    const SizedBox(height: 22),
    Card(child: ListTile(leading: const Icon(Icons.monetization_on), title: const Text('Creator Earnings'), subtitle: const Text('₹0.00 available'), trailing: TextButton(onPressed: () {}, child: const Text('Withdraw')))),
    const Card(child: ListTile(title: Text('Followers'), trailing: Text('0'))),
    const Card(child: ListTile(title: Text('Total Views'), trailing: Text('0'))),
    const Card(child: ListTile(title: Text('Watch Time'), trailing: Text('0 min'))),
  ]);
}

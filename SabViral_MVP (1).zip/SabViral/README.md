# SabViral MVP

Android-first Flutter starter for a Reels-style social app.

## Run
1. Install Flutter.
2. Run `flutter pub get`
3. Run `flutter run`
4. Build APK with `flutter build apk --release`

## Included
- Vertical short-video feed
- Network video playback
- Gallery video picker
- Like interaction
- Profile/creator earnings placeholder
- Reels/Profile/Search navigation

## Production work still needed
Authentication, cloud video storage, database, real comments/follows, moderation, analytics, ads/revenue-share, KYC and real-money payouts.
